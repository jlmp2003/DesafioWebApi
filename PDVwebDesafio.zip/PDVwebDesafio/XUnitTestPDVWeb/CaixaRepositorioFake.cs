﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using PDVwebDesafio.Entities;
using PDVwebDesafio.Repository;
using System;
using System.Collections.Generic;
using System.Linq;

namespace XUnitTestPDVWeb
{
    public class CaixaRepositorioFake : IPCaixaRepository
    {
        private IPCaixaRepository _reppdv;
        public CaixaRepositorioFake(IPCaixaRepository reppdv)
        {
            _reppdv = reppdv;
        }

        private List<Caixa> caixas;
        private IConfiguration _configuration;
        private string resultado;

        public CaixaRepositorioFake()
        {
            caixas = new List<Caixa>()
            {
                new Caixa(){id=1,troco="Troco = R$ 104,45, 1nota(s) de R$100, 2nota(s) de R$2 ,1 moeda(s) de 25 centavo(s)  ,2 moeda(s) de 10 centavo(s)",
                    Data =DateTime.Parse("2020-03-17T09:57:00")},
                new Caixa(){id=2,troco="Troco = R$ 104,45, 1nota(s) de R$100, 2nota(s) de R$2 ,1 moeda(s) de 25 centavo(s)  ,2 moeda(s) de 10 centavo(s)",
                    Data =DateTime.Parse("2020-03-17T09:57:00")},
                new Caixa(){id=3,troco="Troco = R$ 104,45, 1nota(s) de R$100, 2nota(s) de R$2 ,1 moeda(s) de 25 centavo(s)  ,2 moeda(s) de 10 centavo(s)",
                    Data =DateTime.Parse("2020-03-17T09:57:00")},
                new Caixa(){id=4,troco="Troco = R$ 104,45, 1nota(s) de R$100, 2nota(s) de R$2 ,1 moeda(s) de 25 centavo(s)  ,2 moeda(s) de 10 centavo(s)",
                    Data =DateTime.Parse("2020-03-17T09:57:00")}
            };
        }

        

     

        public int Create(CaixaViewModel caixa)
        {
            
            double valorpago = double.Parse(caixa.valorpago);
            double conta = double.Parse(caixa.conta);
            double troco;


            string formatador = new string("###,##0.00");
            if ((valorpago < conta))
            {
                return 0;
            }
            else
            {
                int[] nota = new int[] {
                    100,
                    50,
                    20,
                    10,
                    5,
                    2,
                    1};
                int[] centavos = new int[] {
                    50,
                    25,
                    10,
                    5,
                    1};
                string result;


                int ct;
                int i;
                int vlr;
                troco = (valorpago - conta);
                result = ("Troco = R$ "
                            + ((troco).ToString("###,##0.00")));
                //  definindo as notas do troco (parte inteira)
                vlr = ((int)(troco));
                i = 0;
                while ((vlr != 0))
                {
                    ct = (vlr / nota[i]);
                    //  calculando a qtde de notas
                    if ((ct != 0))
                    {
                        result = (result
                                    + (", " + ct + ("nota(s) de R$"
                                    + (nota[i]))));
                        vlr = (vlr % nota[i]);
                        //  sobra
                    }

                    i = (i + 1);
                    //  proxima nota
                }

                result = (result);
                //  definindo os centavos do troco (parte fracionaria)
                vlr = ((int)(Math.Round((troco - ((int)(troco)))
                                * 100)));
                i = 0;
                while ((vlr != 0))
                {
                    ct = (vlr / centavos[i]);
                    //  calculando a qtde de moedas
                    if ((ct != 0))
                    {
                        result = (result
                                    + (" ," + ct + (" moeda(s) de "
                                    + (centavos[i] + " centavo(s) "))));
                        vlr = (vlr % centavos[i]);
                        //  sobra
                    }

                    i = (i + 1);

                }

                resultado = result.ToString();
            }

            // Console.WriteLine(resultado.ToString());


            //return resultado;


            string Troco = resultado.Replace("\n", ",").Trim();

            /////////

            Caixa pdv = new Caixa();
            DateTime Data = DateTime.Now;
            //   var now = DateTime.Parse(Data.ToString(), new System.Globalization.CultureInfo("en-Us"));
            DateTime now = Convert.ToDateTime((Data).ToString("yyyy-MM-dd  hh:mm"));

            string dt = DateTime.Now.ToString("yyyy-MM-dd");

            //var connectionString = this.GetConnection();
            int count = 0;
            try
            {
                pdv.id = GeraId();
                pdv.troco = Troco;
                pdv.Data = now;
                caixas.Add(pdv);
                count= 1;
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao gravar o item.");
            }
            
            return count;
        }

        int IPCaixaRepository.Delete(int id)
        {
            var item = caixas.First(a => a.id == id);
            caixas.Remove(item);       
            return 1;
        }

        static int GeraId()
        {
            Random random = new Random();
            return random.Next(5, 100);
        }

        // List<Caixa> IPCaixaRepository.GetAll()

        public Caixa GetById(int id)
        {
            return caixas.Where(a => a.id == id)
                .FirstOrDefault();
        }

        public IEnumerable<Caixa> GetAll()
        {
            return caixas;
        }

    }
}
