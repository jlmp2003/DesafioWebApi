using PDVwebDesafio.Controllers;
using PDVwebDesafio.Entities;
using PDVwebDesafio.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using Xunit;
using System;
using System.Web.Http;
using System.Net.Http;
using IdentityModel.Client;
using System.Web.Http.Results;
using System.Net;

namespace XUnitTestPDVWeb
{
    public class ValuesControllerTest
    {
        ValuesController _controller;
        CaixaRepositorioFake _service;
        public ValuesControllerTest()
        {
            _service = new CaixaRepositorioFake();
            _controller = new ValuesController(_service);
        }

        [Fact]
        public void Get_WhenCalled_ReturnsOkResult()
        {
            // Act
            var okResult = _controller.Get();
            // Assert
            Assert.IsType<OkObjectResult>(okResult.Result);
        }
        [Fact]
        public void Get_WhenCalled_ReturnsAllItems()
        {
            // Act
            var okResult = _controller.Get().Result as OkObjectResult;
            // Assert
            var items = Assert.IsType<List<Caixa>>(okResult.Value);
            Assert.Equal(4, items.Count);
        }
       
       
       

        [Fact]
        public void GetById_UnknownGuidPassed_ReturnsNotFoundResult()
        {
            // Act
            var id = 100;
            var notFoundResult = _controller.Get(id);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.NotFoundResult>(notFoundResult.Result);
        }

        
        [Fact]
        public void Add_ValidObjectPassed_ReturnedResponseHasCreatedItem()
        {
            // Arrange
            CaixaViewModel testItem = new CaixaViewModel()
            {
                preco = "120,00",
                valorpago = "80,00",
                conta = "75,00"      //1 nota de 5
            };

            // Act
            var createdResponse = _controller.Create(testItem);
            // Assert
            Assert.IsType<CaixaViewModel>(testItem);
            Assert.Equal("75,00", testItem.conta);
        }

    }
}
