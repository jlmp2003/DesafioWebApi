﻿using Dapper;
using Microsoft.Extensions.Configuration;
using PDVwebDesafio.Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace PDVwebDesafio.Repository
{
    public class CaixaRepository : IPCaixaRepository
    {
        string resultado;
        IConfiguration _configuration;
        public CaixaRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public string GetConnection()
        {
            var connection = _configuration.GetSection("ConnectionStrings").
                                GetSection("PDVConnection").Value;
            return connection;
        }
        public int Create(CaixaViewModel caixa)
        {
            double valorpago = double.Parse(caixa.valorpago);
            double conta = double.Parse(caixa.conta);
            double troco;
           

            string formatador = new string("###,##0.00");
            if ((valorpago < conta))
            {
                return 0;
            }
            else
            {
                int[] nota = new int[] {
                    100,
                    50,
                    20,
                    10,
                    5,
                    2,
                    1};
                int[] centavos = new int[] {
                    50,
                    25,
                    10,
                    5,
                    1};
                string result;


                int ct;
                int i;
                int vlr;
                troco = (valorpago - conta);
                result = ("Troco = R$ "
                            + ((troco).ToString("###,##0.00")));
                //  definindo as notas do troco (parte inteira)
                vlr = ((int)(troco));
                i = 0;
                while ((vlr != 0))
                {
                    ct = (vlr / nota[i]);
                    //  calculando a qtde de notas
                    if ((ct != 0))
                    {
                        result = (result
                                    + (", " + ct + ("nota(s) de R$"
                                    + (nota[i]))));
                        vlr = (vlr % nota[i]);
                        //  sobra
                    }

                    i = (i + 1);
                    //  proxima nota
                }

                result = (result);
                //  definindo os centavos do troco (parte fracionaria)
                vlr = ((int)(Math.Round((troco - ((int)(troco)))
                                * 100)));
                i = 0;
                while ((vlr != 0))
                {
                    ct = (vlr / centavos[i]);
                    //  calculando a qtde de moedas
                    if ((ct != 0))
                    {
                        result = (result
                                    + (" ," + ct + (" moeda(s) de "
                                    + (centavos[i] + " centavo(s) "))));
                        vlr = (vlr % centavos[i]);
                        //  sobra
                    }

                    i = (i + 1);

                }

                resultado = result.ToString();
            }

            // Console.WriteLine(resultado.ToString());


            //return resultado;


            string Troco = resultado.Replace("\n", ",").Trim();

            /////////

            Caixa pdv = new Caixa();
            DateTime Data = DateTime.Now;

            //string[] formats = { "MM/dd/yyyy" };
            //var dateTime = DateTime.ParseExact(Data.ToString("MM/dd/yyyy"), formats, new CultureInfo("en-US"), DateTimeStyles.None); 
            //string dateString = Data.ToString("MM/dd/yyyy");
            //DateTime date = Convert.ToDateTime(dateString, System.Globalization.CultureInfo.GetCultureInfo("en-Us").DateTimeFormat);


            //   var now = DateTime.Parse(Data.ToString(), new System.Globalization.CultureInfo("en-Us"));
            var now = Convert.ToDateTime(Data).ToString("yyyy-MM-dd  hh:mm");

            string dt = DateTime.Now.ToString("yyyy-MM-dd");

            var connectionString = this.GetConnection();
            int count = 0;


            using (var con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    var query = "INSERT INTO SaidaCaixa(Troco, Data) VALUES('" + Troco + "','" + now + "' )";
                    //SELECT CAST(SCOPE_IDENTITY() as INT); ";



                    count = con.Execute(query, pdv);
                }
                catch (Exception ex)
                {
                    throw new Exception("Erro ao gravar o item.");
                }
                finally
                {
                    con.Close();
                }
                return count;
            }
        }

        int IPCaixaRepository.Delete(int id)
        {
            var connectionString = this.GetConnection();
            int count = 0;
            Caixa _caixa = new Caixa();

            using (var con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    var query = "delete * FROM SaidaCaixa WHERE Id =" + id;
                    count = con.Execute(query);
                }
                catch (Exception ex)
                {
                    throw new Exception("Erro ao deletear o item.");
                }
                finally
                {
                    con.Close();
                }
                return count;
            }
        }

        //Caixa IPCaixaRepository.Get(int id)
        //{
        //    var connectionString = this.GetConnection();
        //    Caixa _caixa = new Caixa();
        //    using (var con = new SqlConnection(connectionString))
        //    {
        //        try
        //        {
        //            con.Open();
        //            var query = "SELECT * FROM SaidaCaixa WHERE Id =" + id;
        //            _caixa = con.Query<Caixa>(query).FirstOrDefault();
        //        }
        //        catch (Exception ex)
        //        {
        //            throw ex;
        //        }
        //        finally
        //        {
        //            con.Close();
        //        }
        //        return _caixa;
        //    }
        //}

        //List<Caixa> IPCaixaRepository.GetAll()
        //{
        //    var connectionString = this.GetConnection();
        //    List<Caixa> _caixa = new List<Caixa>();
        //    using (var con = new SqlConnection(connectionString))
        //    {
        //        try
        //        {
        //            con.Open();
        //            var query = "SELECT * FROM SaidaCaixa";
        //            _caixa = con.Query<Caixa>(query).ToList();
        //        }
        //        catch (Exception ex)
        //        {
        //            throw ex;
        //        }
        //        finally
        //        {
        //            con.Close();
        //        }
        //        return _caixa;
        //    }
        //}

        public IEnumerable<Caixa> GetAll()
        {
            var connectionString = this.GetConnection();
            List<Caixa> _caixa = new List<Caixa>();
            using (var con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    var query = "SELECT * FROM SaidaCaixa";
                    _caixa = con.Query<Caixa>(query).ToList();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
                return _caixa;
            }
        }

        public Caixa GetById(int id)
        {
            var connectionString = this.GetConnection();
            Caixa _caixa = new Caixa();
            using (var con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    var query = "SELECT * FROM SaidaCaixa WHERE Id =" + id;
                    _caixa = con.Query<Caixa>(query).FirstOrDefault();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
                return _caixa;
            }
        }
    }
}
