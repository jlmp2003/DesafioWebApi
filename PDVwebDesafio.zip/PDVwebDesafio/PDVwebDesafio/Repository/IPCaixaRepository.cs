﻿using PDVwebDesafio.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PDVwebDesafio.Repository
{
    public interface IPCaixaRepository
    {
        int Create(CaixaViewModel caixa);
        IEnumerable<Caixa> GetAll();
        Caixa GetById(int id);
        int Delete(int id);
    }
}
