﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PDVwebDesafio.Entities
{
    public class Caixa
    {
        public int id { get; set; }
        public string troco { get; set; }
        public DateTime? Data { get; set; }
    }
}
