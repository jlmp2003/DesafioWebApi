﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PDVwebDesafio.Entities
{
    public class CaixaViewModel
    {
            public string preco { get; set; }
            public string conta { get; set; }
            public string valorpago { get; set; }
     
    }
}
