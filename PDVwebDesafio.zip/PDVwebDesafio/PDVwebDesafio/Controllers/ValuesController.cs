﻿using Microsoft.AspNetCore.Mvc;
using PDVwebDesafio.Entities;
using PDVwebDesafio.Repository;
using System;
using System.Collections.Generic;

namespace PDVwebDesafio.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController :  ControllerBase
    {
        private IPCaixaRepository _reppdv;
        public ValuesController(IPCaixaRepository reppdv)
        {
            _reppdv = reppdv;
        }


        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<Caixa>> Get()
        {
            var items = _reppdv.GetAll();
            return Ok(items);
        }

        // GET api/values/5
        [HttpGet("{id}")]
       //\\ public IEnumerable<Caixa> Get(int id)
     public ActionResult<Caixa> Get(int id)
        {
            var item = _reppdv.GetById(id);
            if (item == null)
            {
                return NotFound();
            }
            return Ok(item);
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/values/5
        [HttpPut]
        public ActionResult Create([FromBody] CaixaViewModel caixa)
        {
            if (double.Parse(caixa.valorpago) < double.Parse(caixa.conta))
            {
                 throw new Exception("valor pago insuficiente");
            }
            else
            {
                _reppdv.Create(caixa);
                return Ok(caixa); ;
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {

        }
    }
}
